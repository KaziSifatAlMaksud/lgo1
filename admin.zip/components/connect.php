<?php
// local host
$db_name = 'mysql:host=localhost;dbname=lgorithm_lgorithmbd';
$user_name = 'lgorithm_demo1';
$user_password = '&f]UHC6xrDgH';

// connection variable
$conn = new PDO($db_name, $user_name, $user_password);
